import React, { useMemo, useState, useEffect, useRef } from 'react';

// ─── Counter Hook ──────────────────────────────────────────────────────────
function useCountUp(target, duration = 1800, shouldStart = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!shouldStart) return;
    const numeric = parseInt(String(target).replace(/\D/g, ''), 10);
    if (!numeric) { setCount(target); return; }
    const suffix = String(target).replace(/[0-9]/g, '');
    let start = null;
    const step = (ts) => {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * numeric) + suffix);
      if (progress < 1) requestAnimationFrame(step);
      else setCount(target);
    };
    requestAnimationFrame(step);
  }, [shouldStart, target, duration]);
  return count;
}
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Autoplay } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import './App.css';
import Reveal from './components/Reveal';
import BackToTop from './components/BackToTop';

// ─── API Configuration ─────────────────────────────────────────────────────
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api/v1';

async function apiFetch(path) {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

function mapAbout(data) {
  if (!data) return null;
  return {
    title:       data.companyName || 'WeBuild Construction',
    description: data.description || '',
    heroImage:   data.heroImage   || null,
    stats: [
      { value: data.founded   || '—', label: 'years of experience' },
      { value: data.clients   || '—', label: 'satisfied clients'   },
      { value: data.employees || '—', label: 'active workers'      },
      { value: data.awards    || '—', label: 'awards won'          },
    ],
    phone:     data.phone     || '+123-456-7890',
    email:     data.email     || 'info@webuild.com',
    address:   data.address   || 'Mumbai, India - 400104',
    facebook:  data.facebook  || '#',
    twitter:   data.twitter   || '#',
    instagram: data.instagram || '#',
    linkedin:  data.linkedin  || '#',
    mission:   data.mission   || '',
    vision:    data.vision    || '',
  };
}

// ─── Project Modal ──────────────────────────────────────────────────────────
function ProjectModal({ project, onClose }) {
  const [activePhoto, setActivePhoto] = useState(0);
  const reduceMotion = useReducedMotion();

  // Close on Escape key
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  const images = project.images?.length > 0 ? project.images : [project.image].filter(Boolean);

  const prev = () => setActivePhoto(i => (i - 1 + images.length) % images.length);
  const next = () => setActivePhoto(i => (i + 1) % images.length);

  return (
      <AnimatePresence>
        <motion.div
            className="project-modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.25 }}
            onClick={onClose}
        >
          <motion.div
              className="project-modal"
              initial={{ opacity: 0, y: 40, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 40, scale: 0.97 }}
              transition={{ duration: reduceMotion ? 0 : 0.35, ease: [0.2, 0.8, 0.2, 1] }}
              onClick={e => e.stopPropagation()}
          >
            {/* Close button */}
            <button className="project-modal-close" onClick={onClose} aria-label="Close">
              <i className="fas fa-times" />
            </button>

            {/* Photo gallery */}
            {images.length > 0 && (
                <div className="project-modal-gallery">
                  <div className="project-modal-main-photo">
                    <img src={images[activePhoto]} alt={`${project.title} photo ${activePhoto + 1}`} />

                    {images.length > 1 && (
                        <>
                          <button className="gallery-nav gallery-prev" onClick={prev} aria-label="Previous">
                            <i className="fas fa-chevron-left" />
                          </button>
                          <button className="gallery-nav gallery-next" onClick={next} aria-label="Next">
                            <i className="fas fa-chevron-right" />
                          </button>
                          <span className="gallery-counter">{activePhoto + 1} / {images.length}</span>
                        </>
                    )}
                  </div>

                  {/* Thumbnails */}
                  {images.length > 1 && (
                      <div className="project-modal-thumbs">
                        {images.map((img, i) => (
                            <button
                                key={i}
                                className={`thumb ${i === activePhoto ? 'active' : ''}`}
                                onClick={() => setActivePhoto(i)}
                            >
                              <img src={img} alt={`Thumb ${i + 1}`} />
                            </button>
                        ))}
                      </div>
                  )}
                </div>
            )}

            {/* Details */}
            <div className="project-modal-details">
              <div className="project-modal-header">
                <div>
                  <h2>{project.title}</h2>
                  <span className="project-modal-category">{project.category}</span>
                </div>
                {project.status && (
                    <span className={`project-modal-status project-modal-status--${project.status}`}>
                  {project.status}
                </span>
                )}
              </div>

              {project.description && (
                  <div className="project-modal-section">
                    <h4>About this project</h4>
                    <p>{project.description}</p>
                  </div>
              )}

              {project.services?.length > 0 && (
                  <div className="project-modal-section">
                    <h4>Services used</h4>
                    <div className="project-modal-services">
                      {project.services.map((s, i) => (
                          <span key={i} className="project-service-tag">{s}</span>
                      ))}
                    </div>
                  </div>
              )}

              {project.location && (
                  <div className="project-modal-section">
                    <h4><i className="fas fa-map-marker-alt" /> Location</h4>
                    <p>{project.location}</p>
                  </div>
              )}

              {project.link && (
                  <a
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn project-modal-btn"
                  >
                    view project <i className="fas fa-external-link-alt" />
                  </a>
              )}
            </div>
          </motion.div>
        </motion.div>
      </AnimatePresence>
  );
}

// ─── Animated Stat Box ─────────────────────────────────────────────────────
function StatBox({ stat, index, reduceMotion, easing }) {
  const [inView, setInView] = useState(false);
  const ref = useRef(null);
  const count = useCountUp(stat.value, 1800, inView);

  useEffect(() => {
    const observer = new IntersectionObserver(
        ([entry]) => { if (entry.isIntersecting) { setInView(true); observer.disconnect(); } },
        { threshold: 0.4 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
      <motion.div
          ref={ref}
          className="box"
          variants={{
            hidden: { opacity: 0, y: 12, filter: 'blur(4px)' },
            show: {
              opacity: 1, y: 0, filter: 'blur(0px)',
              transition: reduceMotion ? { duration: 0 } : { duration: 0.55, ease: easing, delay: index * 0.08 },
            },
          }}
      >
        <h3>{inView ? count : 0}</h3>
        <p>{stat.label}</p>
      </motion.div>
  );
}

function StatBoxContainer({ stats, reduceMotion, easing }) {
  return (
      <motion.div
          className="box-container"
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-80px' }}
          variants={{ hidden: {}, show: {} }}
      >
        {stats.map((stat, index) => (
            <StatBox key={index} stat={stat} index={index} reduceMotion={reduceMotion} easing={easing} />
        ))}
      </motion.div>
  );
}

// ─── Main App ───────────────────────────────────────────────────────────────
function App() {
  const reduceMotion = useReducedMotion();
  const [activeMenu, setActiveMenu] = useState({
    navbar: false, searchForm: false, loginForm: false, contactInfo: false,
  });
  const [activeHomeSlide, setActiveHomeSlide] = useState(0);
  const [contactStatus, setContactStatus] = useState(null);
  const [selectedProject, setSelectedProject] = useState(null);

  const easing = useMemo(() => (reduceMotion ? 'linear' : [0.2, 0.8, 0.2, 1]), [reduceMotion]);

  const hero = useMemo(() => ({
    container: {
      hidden: { opacity: 0, y: 14 },
      show: {
        opacity: 1, y: 0,
        transition: reduceMotion
            ? { duration: 0 }
            : { duration: 0.7, ease: easing, staggerChildren: 0.08 },
      },
    },
    item: {
      hidden: { opacity: 0, y: 14 },
      show: reduceMotion
          ? { opacity: 1, y: 0, transition: { duration: 0 } }
          : { opacity: 1, y: 0, transition: { duration: 0.55, ease: easing } },
    },
  }), [reduceMotion, easing]);

  const [homeSlides, setHomeSlides] = useState([]);
  const [aboutData,  setAboutData]  = useState(null);
  const [services,   setServices]   = useState([]);
  const [projects,   setProjects]   = useState([]);
  const [loading,    setLoading]    = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [slidersRes, aboutRes, servicesRes, projectsRes] = await Promise.all([
          apiFetch('/public/sliders'),
          apiFetch('/public/about'),
          apiFetch('/public/services'),
          apiFetch('/public/projects'),
        ]);

        const slidersArr = slidersRes?.data ?? slidersRes ?? [];
        setHomeSlides(slidersArr.map(s => ({
          id:          s.id,
          title:       s.title,
          description: s.subtitle || '',
          image:       s.image,
          buttonText:  s.buttonText || 'Get Started',
          buttonLink:  s.buttonLink || '#about',
        })));

        const aboutRaw = aboutRes?.data ?? aboutRes ?? {};
        setAboutData(mapAbout(aboutRaw));

        const servicesArr = servicesRes?.data ?? servicesRes ?? [];
        setServices(servicesArr.map(s => ({
          id:          s.id,
          title:       s.title,
          description: s.description,
          image:       s.image,
        })));

        // Keep ALL project fields for the modal
        const projectsArr = projectsRes?.data ?? projectsRes ?? [];
        setProjects(projectsArr.map(p => ({
          id:          p.id,
          title:       p.title,
          description: p.description,
          category:    p.category,
          images:      p.images ?? [],
          image:       p.images?.[0] || '',
          services:    p.services ?? [],
          status:      p.status,
          location:    p.location,
          link:        p.link,
        })));
      } catch (err) {
        console.error('Failed to fetch data:', err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const closeAllMenus = () =>
      setActiveMenu({ navbar: false, searchForm: false, loginForm: false, contactInfo: false });

  const toggleMenu = (menu) =>
      setActiveMenu(prev => ({
        navbar:      menu === 'navbar'      ? !prev.navbar      : false,
        searchForm:  menu === 'searchForm'  ? !prev.searchForm  : false,
        loginForm:   menu === 'loginForm'   ? !prev.loginForm   : false,
        contactInfo: menu === 'contactInfo' ? !prev.contactInfo : false,
      }));

  useEffect(() => {
    const onScroll  = () => closeAllMenus();
    const onKeyDown = (e) => { if (e.key === 'Escape' && !selectedProject) closeAllMenus(); };
    window.addEventListener('scroll',  onScroll);
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('scroll',  onScroll);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [selectedProject]);

  const motionEase   = useMemo(() => (reduceMotion ? 'linear' : [0.2, 0.8, 0.2, 1]), [reduceMotion]);
  const motionFast   = useMemo(() => ({ duration: reduceMotion ? 0 : 0.22, ease: motionEase }), [reduceMotion, motionEase]);
  const motionNormal = useMemo(() => ({ duration: reduceMotion ? 0 : 0.55, ease: motionEase }), [reduceMotion, motionEase]);

  const handleSearch  = (e) => { e.preventDefault(); };
  const handleLogin   = (e) => { e.preventDefault(); };

  const handleContact = async (e) => {
    e.preventDefault();
    setContactStatus('sending');
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setContactStatus('ok');
      e.target.reset();
    } catch {
      setContactStatus('error');
    }
  };

  if (loading) {
    return (
        <div className="loading-screen">
          <div className="loader"></div>
          <p>Loading...</p>
        </div>
    );
  }

  return (
      <div className="App">

        {/* ── Project Modal ──────────────────────────────────────────────────── */}
        <AnimatePresence>
          {selectedProject && (
              <ProjectModal
                  project={selectedProject}
                  onClose={() => setSelectedProject(null)}
              />
          )}
        </AnimatePresence>

        {/* ── Header ─────────────────────────────────────────────────────────── */}
        <motion.header
            className="header"
            initial={{ y: -10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={motionNormal}
        >
          <a href="#home" className="logo">We<span>Build</span></a>

          <nav className={`navbar ${activeMenu.navbar ? 'active' : ''}`}>
            <a href="#home">home</a>
            <a href="#about">about</a>
            <a href="#services">services</a>
            <a href="#projects">projects</a>
            <a href="#contact">contact</a>
          </nav>

          <div className="icons">
            <div id="menu-btn"    className="fas fa-bars"        onClick={() => toggleMenu('navbar')}      />
            <div id="info-btn"    className="fas fa-info-circle" onClick={() => toggleMenu('contactInfo')} title="Contact Info" />
            <div id="search-btn"  className="fas fa-search"      onClick={() => toggleMenu('searchForm')}  title="Search" />
            <div id="login-btn"   className="fas fa-user"         onClick={() => toggleMenu('loginForm')}   title="Login" />
          </div>

          <AnimatePresence>
            {activeMenu.searchForm && (
                <motion.form
                    key="search"
                    className="search-form modern-popover"
                    onSubmit={handleSearch}
                    initial={{ opacity: 0, y: -10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.98 }}
                    transition={motionFast}
                >
                  <input type="search" name="search" placeholder="search here..." id="search-box" autoFocus />
                  <label htmlFor="search-box" className="fas fa-search" />
                </motion.form>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {activeMenu.loginForm && (
                <motion.form
                    key="login"
                    className="login-form modern-popover"
                    onSubmit={handleLogin}
                    initial={{ opacity: 0, y: -10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.98 }}
                    transition={motionFast}
                >
                  <h3>login form</h3>
                  <input type="email"    name="email"    placeholder="enter your email"    className="box" />
                  <input type="password" name="password" placeholder="enter your password" className="box" />
                  <div className="flex">
                    <input type="checkbox" name="remember" id="remember-me" />
                    <label htmlFor="remember-me">remember me</label>
                    <a href="#forgot">forgot password?</a>
                  </div>
                  <input type="submit" value="login now" className="btn" />
                  <p>don't have an account <a href="#register">create one!</a></p>
                </motion.form>
            )}
          </AnimatePresence>
        </motion.header>

        {/* ── Contact Info Sidebar ───────────────────────────────────────────── */}
        <AnimatePresence>
          {activeMenu.contactInfo && (
              <>
                <motion.div
                    className="overlay"
                    onClick={closeAllMenus}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={motionFast}
                />
                <motion.aside
                    className="contact-info-panel"
                    role="dialog"
                    aria-modal="true"
                    aria-label="Contact information"
                    initial={{ x: 24, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    exit={{ x: 24, opacity: 0 }}
                    transition={motionNormal}
                >
                  <button type="button" className="contact-close" onClick={closeAllMenus} aria-label="Close">
                    <i className="fas fa-times" />
                  </button>
                  <div className="info">
                    <i className="fas fa-phone" />
                    <h3>phone number</h3>
                    <p>{aboutData?.phone || '+123-456-7890'}</p>
                  </div>
                  <div className="info">
                    <i className="fas fa-envelope" />
                    <h3>email address</h3>
                    <p>{aboutData?.email || 'info@webuild.com'}</p>
                  </div>
                  <div className="info">
                    <i className="fas fa-map-marker-alt" />
                    <h3>office address</h3>
                    <p>{aboutData?.address || 'Mumbai, India - 400104'}</p>
                  </div>
                  <div className="share">
                    <a href={aboutData?.facebook  || '#'} className="fab fa-facebook-f"  aria-label="Facebook"  />
                    <a href={aboutData?.twitter   || '#'} className="fab fa-twitter"      aria-label="Twitter"   />
                    <a href={aboutData?.instagram || '#'} className="fab fa-instagram"    aria-label="Instagram" />
                    <a href={aboutData?.linkedin  || '#'} className="fab fa-linkedin"     aria-label="LinkedIn"  />
                  </div>
                </motion.aside>
              </>
          )}
        </AnimatePresence>

        {/* ── Home / Hero Slider ─────────────────────────────────────────────── */}
        {homeSlides.length > 0 && (
            <section className="home" id="home">
              <Swiper
                  modules={[Navigation, Autoplay]}
                  navigation
                  loop={homeSlides.length > 1}
                  grabCursor
                  onSwiper={swiper => setActiveHomeSlide(swiper.realIndex)}
                  onSlideChange={swiper => setActiveHomeSlide(swiper.realIndex)}
                  autoplay={{ delay: 5000, disableOnInteraction: false }}
                  className="home-slider"
              >
                {homeSlides.map((slide, index) => (
                    <SwiperSlide
                        key={slide.id}
                        className="slide"
                        style={{ backgroundImage: `url(${slide.image})` }}
                    >
                      <motion.div
                          className="content"
                          variants={hero.container}
                          initial="hidden"
                          animate={activeHomeSlide === index ? 'show' : 'hidden'}
                      >
                        <motion.h3 variants={hero.item}>{slide.title}</motion.h3>
                        <motion.p  variants={hero.item}>{slide.description}</motion.p>
                        <motion.a
                            variants={hero.item}
                            href={slide.buttonLink}
                            className="btn"
                            whileHover={reduceMotion ? undefined : { y: -1 }}
                            whileTap={reduceMotion   ? undefined : { scale: 0.98 }}
                        >
                          {slide.buttonText}
                        </motion.a>
                      </motion.div>
                    </SwiperSlide>
                ))}
              </Swiper>
            </section>
        )}

        {/* ── About ──────────────────────────────────────────────────────────── */}
        {aboutData && (
            <section className="about" id="about">
              <Reveal>
                <h1 className="heading">about us</h1>
              </Reveal>

              <Reveal>
                <div className="row">
                  {aboutData.heroImage ? (
                      <div className="image-wrapper">
                        <img src={aboutData.heroImage} alt={aboutData.title} className="about-hero-img" />
                      </div>
                  ) : (
                      <div className="video">
                        <video src="https://www.w3schools.com/html/mov_bbb.mp4" loop muted autoPlay />
                      </div>
                  )}
                  <div className="content">
                    <h3>{aboutData.title}</h3>
                    <p>{aboutData.description}</p>
                    {aboutData.mission && <p className="mission-text"><em>{aboutData.mission}</em></p>}
                    <a href="#services" className="btn">our services</a>
                  </div>
                </div>
              </Reveal>

              <StatBoxContainer stats={aboutData.stats} reduceMotion={reduceMotion} easing={easing} />
            </section>
        )}

        {/* ── Services ───────────────────────────────────────────────────────── */}
        {services.length > 0 && (
            <section className="services" id="services">
              <Reveal>
                <h1 className="heading">our services</h1>
              </Reveal>

              <motion.div
                  className="box-container"
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true, margin: '-120px' }}
                  variants={{
                    hidden: {},
                    show: { transition: { staggerChildren: reduceMotion ? 0 : 0.06 } },
                  }}
              >
                {services.map((service) => (
                    <motion.div
                        key={service.id}
                        className="box card"
                        variants={{
                          hidden: { opacity: 0, y: 14, filter: 'blur(4px)' },
                          show: {
                            opacity: 1, y: 0, filter: 'blur(0px)',
                            transition: reduceMotion ? { duration: 0 } : { duration: 0.5, ease: easing },
                          },
                        }}
                        whileHover={reduceMotion ? undefined : { y: -6, rotate: -0.2 }}
                        whileTap={reduceMotion   ? undefined : { scale: 0.99 }}
                    >
                      <img src={service.image} alt={service.title} />
                      <h3>{service.title}</h3>
                      <p>{service.description}</p>
                    </motion.div>
                ))}
              </motion.div>
            </section>
        )}

        {/* ── Projects ───────────────────────────────────────────────────────── */}
        {projects.length > 0 && (
            <section className="projects" id="projects">
              <Reveal>
                <h1 className="heading">our projects</h1>
              </Reveal>

              <motion.div
                  className="box-container"
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true, margin: '-120px' }}
                  variants={{
                    hidden: {},
                    show: { transition: { staggerChildren: reduceMotion ? 0 : 0.06 } },
                  }}
              >
                {projects.map((project) => (
                    <motion.div
                        key={project.id}
                        className="box card"
                        onClick={() => setSelectedProject(project)}
                        style={{ cursor: 'pointer' }}
                        variants={{
                          hidden: { opacity: 0, y: 14, filter: 'blur(4px)' },
                          show: {
                            opacity: 1, y: 0, filter: 'blur(0px)',
                            transition: reduceMotion ? { duration: 0 } : { duration: 0.55, ease: easing },
                          },
                        }}
                        whileHover={reduceMotion ? undefined : { y: -6 }}
                        whileTap={reduceMotion   ? undefined : { scale: 0.99 }}
                    >
                      <div className="image">
                        <img src={project.image} alt={project.title} />
                      </div>
                      <div className="content">
                        <div className="info">
                          <h3>{project.title}</h3>
                          <p>{project.category}</p>
                        </div>
                        <i className="fas fa-plus" />
                      </div>
                    </motion.div>
                ))}
              </motion.div>
            </section>
        )}

        {/* ── Contact ────────────────────────────────────────────────────────── */}
        <section className="contact" id="contact">
          <Reveal>
            <h1 className="heading">contact us</h1>
          </Reveal>

          <Reveal>
            <div className="row">
              <motion.iframe
                  className="map"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15076.89592087332!2d72.8319697277345!3d19.14167056419224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b63aceef0c69%3A0x2aa80cf2287dfa3b!2sJogeshwari%20West%2C%20Mumbai%2C%20Maharashtra%20400047!5e0!3m2!1sen!2sin!4v1641716772852!5m2!1sen!2sin"
                  allowFullScreen=""
                  loading="lazy"
                  title="Office Location"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-120px' }}
                  transition={{ duration: reduceMotion ? 0 : 0.5, ease: easing }}
              />

              <motion.form
                  onSubmit={handleContact}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-120px' }}
                  transition={{ duration: reduceMotion ? 0 : 0.5, ease: easing, delay: reduceMotion ? 0 : 0.06 }}
              >
                <h3>get in touch</h3>
                <input type="text"  name="name"    placeholder="name"    className="box" required />
                <input type="email" name="email"   placeholder="email"   className="box" required />
                <input type="tel"   name="phone"   placeholder="phone"   className="box" required />
                <textarea name="message" placeholder="message" className="box" cols="30" rows="10" required />

                {contactStatus === 'ok' && (
                    <p style={{ color: 'var(--yellow)', fontSize: '1.5rem', marginTop: '1rem' }}>
                      ✓ Message sent successfully!
                    </p>
                )}
                {contactStatus === 'error' && (
                    <p style={{ color: '#e55', fontSize: '1.5rem', marginTop: '1rem' }}>
                      ✗ Failed to send. Please try again.
                    </p>
                )}

                <input
                    type="submit"
                    value={contactStatus === 'sending' ? 'sending...' : 'send message'}
                    className="btn"
                    disabled={contactStatus === 'sending'}
                />
              </motion.form>
            </div>
          </Reveal>
        </section>

        {/* ── Footer ─────────────────────────────────────────────────────────── */}
        <section className="footer">
          <div className="links">
            <a className="btn" href="#home">home</a>
            <a className="btn" href="#about">about</a>
            <a className="btn" href="#services">services</a>
            <a className="btn" href="#projects">projects</a>
            <a className="btn" href="#contact">contact</a>
          </div>
          <div className="credit">
            powered by <span>{aboutData?.title || 'WeBuild'}</span>
          </div>
        </section>

        <BackToTop />
      </div>
  );
}

export default App;